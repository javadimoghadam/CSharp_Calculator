﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CalCulator_app
{
    interface ICalculate
    {
        // Divide - تقسیم
        int Divide(int Number1 , int Number2);
        // Multiple - ضرب
        int Multiple(int Number1, int Number2);
        // Plus - جمع
        int Plus(int Number1, int Number2);
        // Minus - تقسیم
        int Minus(int Number1, int Number2);
        // Radical - رادیکال
        double Radical(double Number);
        // Power - توان 
        double Power(double Number, double power);
    }
}
