﻿namespace CalCulator_app
{
    partial class Information
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.CloseFrm_Btn = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.groupBox1.SuspendLayout();
            this.groupBox2.SuspendLayout();
            this.SuspendLayout();
            // 
            // CloseFrm_Btn
            // 
            this.CloseFrm_Btn.BackColor = System.Drawing.Color.Green;
            this.CloseFrm_Btn.Cursor = System.Windows.Forms.Cursors.Hand;
            this.CloseFrm_Btn.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.CloseFrm_Btn.Font = new System.Drawing.Font("IRANSans", 8.999999F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.CloseFrm_Btn.ForeColor = System.Drawing.Color.White;
            this.CloseFrm_Btn.Location = new System.Drawing.Point(12, 284);
            this.CloseFrm_Btn.Name = "CloseFrm_Btn";
            this.CloseFrm_Btn.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.CloseFrm_Btn.Size = new System.Drawing.Size(416, 31);
            this.CloseFrm_Btn.TabIndex = 0;
            this.CloseFrm_Btn.Text = "فهمیدم !";
            this.CloseFrm_Btn.UseVisualStyleBackColor = false;
            this.CloseFrm_Btn.Click += new System.EventHandler(this.CloseFrm_Btn_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(27, 28);
            this.label1.Name = "label1";
            this.label1.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.label1.Size = new System.Drawing.Size(375, 45);
            this.label1.TabIndex = 1;
            this.label1.Text = "برای استفاده از چهار عمل اصلی ابتدا عدد اول و سپس عدد دوم را وارد کرده و\r\n\r\n روی " +
    "دکمه مورد نظر ( جمع و ضرب و ... ) کلیک کنید . ";
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.label1);
            this.groupBox1.Location = new System.Drawing.Point(12, 12);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(416, 99);
            this.groupBox1.TabIndex = 2;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "عملیات های اصلی ";
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.label3);
            this.groupBox2.Controls.Add(this.label2);
            this.groupBox2.Location = new System.Drawing.Point(12, 128);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(416, 137);
            this.groupBox2.TabIndex = 2;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "عملیات های فرعی ";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(105, 93);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(297, 30);
            this.label2.TabIndex = 3;
            this.label2.Text = "رادیکال : برای رادیکال شما فقط عدد اول را وارد کرده و بر روی\r\n دکمه رادیکال کلیک " +
    "کنید . ";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(17, 30);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(385, 45);
            this.label3.TabIndex = 4;
            this.label3.Text = "توان : برای توان ابتدا عددی را که میخواهید به توان برسد را در عدد اول وارد کرده\r\n" +
    "\r\n و مقدار توانی را می خواهید عددتان به آن برسد را در عدد دوم وارد کنید .";
            // 
            // Information
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(440, 339);
            this.Controls.Add(this.groupBox2);
            this.Controls.Add(this.groupBox1);
            this.Controls.Add(this.CloseFrm_Btn);
            this.Cursor = System.Windows.Forms.Cursors.Default;
            this.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.Name = "Information";
            this.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.RightToLeftLayout = true;
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "آموزش استفاده از ماشین حساب";
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button CloseFrm_Btn;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
    }
}