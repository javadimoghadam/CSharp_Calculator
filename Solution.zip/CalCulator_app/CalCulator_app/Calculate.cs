﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CalCulator_app
{
    class Calculate : ICalculate
    {
        public int Divide(int Number1, int Number2)
        {
            return Number1 / Number2;
        }

        public int Minus(int Number1, int Number2)
        {
            return Number1 - Number2;

        }

        public int Multiple(int Number1, int Number2)
        {
            return Number1 * Number2;
        }

        public int Plus(int Number1, int Number2)
        {
            return Number1 + Number2;
        }

        public double Radical(double Number)
        {
            return Math.Sqrt(Number);
        }
        public double Power(double Number, double power)
        {
            return Math.Pow(Number, power);
        }

    }
}
