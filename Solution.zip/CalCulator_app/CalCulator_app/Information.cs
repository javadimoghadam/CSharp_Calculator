﻿/*
    Calculator Project 
    Programmed By Ali javadi 
    Email : javadimoghadammail@gmail.com
    Date of making the program : 10/15/2019 -- 1398/07/23 
*/

using System;
using System.Windows.Forms;

namespace CalCulator_app
{
    public partial class Information : Form
    {
        public Information()
        {
            InitializeComponent();
        }

        private void CloseFrm_Btn_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
