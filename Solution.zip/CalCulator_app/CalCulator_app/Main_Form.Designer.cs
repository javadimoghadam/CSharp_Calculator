﻿namespace CalCulator_app
{
    partial class Main_Form
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Main_Form));
            this.Plusbtn = new System.Windows.Forms.Button();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.dividebtn = new System.Windows.Forms.Button();
            this.Multiplebtn = new System.Windows.Forms.Button();
            this.Minusbtn = new System.Windows.Forms.Button();
            this.First_Number = new System.Windows.Forms.NumericUpDown();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.Second_Number = new System.Windows.Forms.NumericUpDown();
            this.lblShow = new System.Windows.Forms.Label();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.Powerbtn = new System.Windows.Forms.Button();
            this.Radicalbtn = new System.Windows.Forms.Button();
            this.toolStrip1 = new System.Windows.Forms.ToolStrip();
            this.Informationbtn = new System.Windows.Forms.ToolStripButton();
            this.datelbl = new System.Windows.Forms.Label();
            this.groupBox1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.First_Number)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.Second_Number)).BeginInit();
            this.groupBox2.SuspendLayout();
            this.toolStrip1.SuspendLayout();
            this.SuspendLayout();
            // 
            // Plusbtn
            // 
            this.Plusbtn.Cursor = System.Windows.Forms.Cursors.Hand;
            this.Plusbtn.Location = new System.Drawing.Point(25, 27);
            this.Plusbtn.Name = "Plusbtn";
            this.Plusbtn.Size = new System.Drawing.Size(75, 23);
            this.Plusbtn.TabIndex = 0;
            this.Plusbtn.Text = "جمع";
            this.Plusbtn.UseVisualStyleBackColor = true;
            this.Plusbtn.Click += new System.EventHandler(this.Plusbtn_Click);
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.dividebtn);
            this.groupBox1.Controls.Add(this.Multiplebtn);
            this.groupBox1.Controls.Add(this.Minusbtn);
            this.groupBox1.Controls.Add(this.Plusbtn);
            this.groupBox1.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.groupBox1.Location = new System.Drawing.Point(12, 100);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(379, 63);
            this.groupBox1.TabIndex = 1;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "عملیات های اصلی ";
            // 
            // dividebtn
            // 
            this.dividebtn.Cursor = System.Windows.Forms.Cursors.Hand;
            this.dividebtn.Location = new System.Drawing.Point(268, 27);
            this.dividebtn.Name = "dividebtn";
            this.dividebtn.Size = new System.Drawing.Size(75, 23);
            this.dividebtn.TabIndex = 3;
            this.dividebtn.Text = "تقسیم";
            this.dividebtn.UseVisualStyleBackColor = true;
            this.dividebtn.Click += new System.EventHandler(this.Dividebtn_Click_1);
            // 
            // Multiplebtn
            // 
            this.Multiplebtn.Cursor = System.Windows.Forms.Cursors.Hand;
            this.Multiplebtn.Location = new System.Drawing.Point(187, 27);
            this.Multiplebtn.Name = "Multiplebtn";
            this.Multiplebtn.Size = new System.Drawing.Size(75, 23);
            this.Multiplebtn.TabIndex = 2;
            this.Multiplebtn.Text = "ضرب";
            this.Multiplebtn.UseVisualStyleBackColor = true;
            this.Multiplebtn.Click += new System.EventHandler(this.Multiplebtn_Click);
            // 
            // Minusbtn
            // 
            this.Minusbtn.Cursor = System.Windows.Forms.Cursors.Hand;
            this.Minusbtn.Location = new System.Drawing.Point(106, 27);
            this.Minusbtn.Name = "Minusbtn";
            this.Minusbtn.Size = new System.Drawing.Size(75, 23);
            this.Minusbtn.TabIndex = 1;
            this.Minusbtn.Text = "کسر";
            this.Minusbtn.UseVisualStyleBackColor = true;
            this.Minusbtn.Click += new System.EventHandler(this.Minusbtn_Click);
            // 
            // First_Number
            // 
            this.First_Number.Cursor = System.Windows.Forms.Cursors.Hand;
            this.First_Number.Location = new System.Drawing.Point(12, 36);
            this.First_Number.Name = "First_Number";
            this.First_Number.Size = new System.Drawing.Size(317, 22);
            this.First_Number.TabIndex = 2;
            this.First_Number.ValueChanged += new System.EventHandler(this.First_Number_ValueChanged);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.label1.Location = new System.Drawing.Point(335, 39);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(52, 15);
            this.label1.TabIndex = 3;
            this.label1.Text = "عدد اول :";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.label2.Location = new System.Drawing.Point(335, 67);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(54, 15);
            this.label2.TabIndex = 4;
            this.label2.Text = "عدد دوم :";
            // 
            // Second_Number
            // 
            this.Second_Number.Cursor = System.Windows.Forms.Cursors.Hand;
            this.Second_Number.Location = new System.Drawing.Point(12, 64);
            this.Second_Number.Name = "Second_Number";
            this.Second_Number.Size = new System.Drawing.Size(317, 22);
            this.Second_Number.TabIndex = 5;
            this.Second_Number.ValueChanged += new System.EventHandler(this.Second_Number_ValueChanged);
            // 
            // lblShow
            // 
            this.lblShow.AutoSize = true;
            this.lblShow.Font = new System.Drawing.Font("Segoe UI", 10F);
            this.lblShow.ForeColor = System.Drawing.Color.Green;
            this.lblShow.Location = new System.Drawing.Point(105, 245);
            this.lblShow.Name = "lblShow";
            this.lblShow.Size = new System.Drawing.Size(0, 19);
            this.lblShow.TabIndex = 6;
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.Powerbtn);
            this.groupBox2.Controls.Add(this.Radicalbtn);
            this.groupBox2.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.groupBox2.Location = new System.Drawing.Point(12, 169);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(379, 63);
            this.groupBox2.TabIndex = 4;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "عملیات های فرعی ";
            // 
            // Powerbtn
            // 
            this.Powerbtn.Cursor = System.Windows.Forms.Cursors.Hand;
            this.Powerbtn.Location = new System.Drawing.Point(25, 27);
            this.Powerbtn.Name = "Powerbtn";
            this.Powerbtn.Size = new System.Drawing.Size(156, 23);
            this.Powerbtn.TabIndex = 4;
            this.Powerbtn.Text = "توان";
            this.Powerbtn.UseVisualStyleBackColor = true;
            this.Powerbtn.Click += new System.EventHandler(this.Powerbtn_Click);
            // 
            // Radicalbtn
            // 
            this.Radicalbtn.Cursor = System.Windows.Forms.Cursors.Hand;
            this.Radicalbtn.Location = new System.Drawing.Point(187, 27);
            this.Radicalbtn.Name = "Radicalbtn";
            this.Radicalbtn.Size = new System.Drawing.Size(156, 23);
            this.Radicalbtn.TabIndex = 3;
            this.Radicalbtn.Text = "رادیکال";
            this.Radicalbtn.UseVisualStyleBackColor = true;
            this.Radicalbtn.Click += new System.EventHandler(this.Radicalbtn_Click);
            // 
            // toolStrip1
            // 
            this.toolStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.Informationbtn});
            this.toolStrip1.Location = new System.Drawing.Point(0, 0);
            this.toolStrip1.Name = "toolStrip1";
            this.toolStrip1.Size = new System.Drawing.Size(399, 25);
            this.toolStrip1.TabIndex = 7;
            this.toolStrip1.Text = "toolStrip1";
            // 
            // Informationbtn
            // 
            this.Informationbtn.Image = ((System.Drawing.Image)(resources.GetObject("Informationbtn.Image")));
            this.Informationbtn.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.Informationbtn.Name = "Informationbtn";
            this.Informationbtn.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.Informationbtn.Size = new System.Drawing.Size(105, 22);
            this.Informationbtn.Text = "آموزش استفاده ";
            this.Informationbtn.Click += new System.EventHandler(this.Informationbtn_Click);
            // 
            // datelbl
            // 
            this.datelbl.AutoSize = true;
            this.datelbl.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.datelbl.Location = new System.Drawing.Point(2, 6);
            this.datelbl.Name = "datelbl";
            this.datelbl.Size = new System.Drawing.Size(0, 15);
            this.datelbl.TabIndex = 8;
            // 
            // Main_Form
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(399, 274);
            this.Controls.Add(this.datelbl);
            this.Controls.Add(this.toolStrip1);
            this.Controls.Add(this.groupBox2);
            this.Controls.Add(this.lblShow);
            this.Controls.Add(this.Second_Number);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.First_Number);
            this.Controls.Add(this.groupBox1);
            this.Cursor = System.Windows.Forms.Cursors.Hand;
            this.Font = new System.Drawing.Font("Segoe UI", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedToolWindow;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "Main_Form";
            this.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.StartPosition = System.Windows.Forms.FormStartPosition.Manual;
            this.Text = "ماشین حساب من";
            this.groupBox1.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.First_Number)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.Second_Number)).EndInit();
            this.groupBox2.ResumeLayout(false);
            this.toolStrip1.ResumeLayout(false);
            this.toolStrip1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button Plusbtn;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.NumericUpDown First_Number;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.NumericUpDown Second_Number;
        private System.Windows.Forms.Button dividebtn;
        private System.Windows.Forms.Button Multiplebtn;
        private System.Windows.Forms.Button Minusbtn;
        private System.Windows.Forms.Label lblShow;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.Button Radicalbtn;
        private System.Windows.Forms.Button Powerbtn;
        private System.Windows.Forms.ToolStrip toolStrip1;
        private System.Windows.Forms.ToolStripButton Informationbtn;
        private System.Windows.Forms.Label datelbl;
    }
}

