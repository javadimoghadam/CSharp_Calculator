﻿/*
    Calculator Project 
    Programmed By Ali javadi 
    Email : javadimoghadammail@gmail.com
    Date of making the program : 10/15/2019 -- 1398/07/23 
*/

using System;
using System.Windows.Forms;
using System.Globalization;

namespace CalCulator_app
{
    public partial class Main_Form : Form
    {
        ICalculate Calculate;
        PersianCalendar PersianDate = new PersianCalendar();
        public Main_Form()
        {
            InitializeComponent();
            Calculate = new Calculate();
            string persianDate = PersianDate.GetYear(DateTime.Now) + "/" + PersianDate.GetMonth(DateTime.Now) + "/" + PersianDate.GetDayOfMonth(DateTime.Now);
            datelbl.Text = $"تاریخ امروز : {persianDate}‌ ";
        }

        private void First_Number_ValueChanged(object sender, EventArgs e)
        {

        }

        private void Second_Number_ValueChanged(object sender, EventArgs e)
        {

        }

        private void Plusbtn_Click(object sender, EventArgs e)
        {
            if (ValidInput())
            {

                int sum = Calculate.Plus((int)First_Number.Value, (int)Second_Number.Value);
                lblShow.Text = $"جمع اعداد شما برابر است با : {sum} ";
            }
        }
        private void Minusbtn_Click(object sender, EventArgs e)
        {
            if (ValidInput())
            {
                int sum = Calculate.Minus((int)First_Number.Value, (int)Second_Number.Value);
                lblShow.Text = $"کسر اعداد شما برابر است با : {sum} ";
            }
        }

        private void Multiplebtn_Click(object sender, EventArgs e)
        {
            if (ValidInput())
            {
                int sum = Calculate.Multiple((int)First_Number.Value, (int)Second_Number.Value);
                lblShow.Text = $"ضرب اعداد شما برابر است با : {sum} ";
            }
        }

        private void Dividebtn_Click_1(object sender, EventArgs e)
        {
            if (ValidInput())
            {
                int sum = Calculate.Divide((int)First_Number.Value, (int)Second_Number.Value);
                lblShow.Text = $"تقسیم اعداد شما برابر است با : {sum} ";
            }
        }

        private void Radicalbtn_Click(object sender, EventArgs e)
        {
            double sum = Calculate.Radical((Double)First_Number.Value);
            lblShow.Text = $"جواب رادیکال برابر است با : {sum}";

        }

        private void Powerbtn_Click(object sender, EventArgs e)
        {
            double sum = Calculate.Power((double)First_Number.Value, (double)Second_Number.Value);
            lblShow.Text = $"جواب توان برابر است با : {sum}";
        }

        // Empty Checker 

        bool ValidInput()
        {
            bool IsValid = true;

            if (First_Number.Value == 0)
            {
                IsValid = false;
                MessageBox.Show("لطفا عدد اول را وارد کنید .", "خطا !", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            else
            {
                if(Second_Number.Value == 0)
                {
                    IsValid = false;
                    MessageBox.Show("لطفا عدد دوم را وارد کنید .", "خطا !", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }

            return IsValid;
        }

        private void Informationbtn_Click(object sender, EventArgs e)
        {
            Information Frminfo = new Information();
            Frminfo.ShowDialog();

        }
    }
}
